package futbolista;

public class Futbolista {
	private String nombre;
    private int edad;
    private String posicion;
    private String equipo;

    public Futbolista(String nombre, int edad, String posicion, String equipo) {
        this.nombre = nombre;
        this.edad = edad;
        this.posicion = posicion;
        this.equipo = equipo;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre;
    
    }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad;
    
    }

    public String getPosicion() { return posicion; }
    public void setPosicion(String posicion) { this.posicion = posicion; 
    
    }

    public String getEquipo() { return equipo; }
    public void setEquipo(String equipo) { this.equipo = equipo;
    
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Posición: " + posicion);
        System.out.println("Equipo: " + equipo);
    }
}

class Delantero extends Futbolista {
    public Delantero(String nombre, int edad, String posicion, String equipo) {
        super(nombre, edad, posicion, equipo);
    }
}

class Defensa extends Futbolista {
    public Defensa(String nombre, int edad, String posicion, String equipo) {
        super(nombre, edad, posicion, equipo);
    }
}

class Entrenador extends Futbolista {
    public Entrenador(String nombre, int edad, String posicion, String equipo) {
        super(nombre, edad, posicion, equipo);
    }
}

class Portero extends Futbolista {
    public Portero(String nombre, int edad, String posicion, String equipo) {
        super(nombre, edad, posicion, equipo);
    }
}


    

    
