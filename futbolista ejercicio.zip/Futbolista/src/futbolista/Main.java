package futbolista;

public class Main {
	public static void main(String[] args) {
        Delantero f1 = new Delantero("Jose", 20, "Delantero", "Guatemala FC");
        Defensa f2 = new Defensa("Isaac", 18, "Defensa", "Municipal");
        Mediocampista f3 = new Mediocampista("Samuel", 21, "Entrenador", "Rabinal");
        Portero f4 = new Portero("Alberto", 19, "Portero", "Cobán ");

        f1.mostrarInformacion();
        System.out.println();
        f2.mostrarInformacion();
        System.out.println();
        f3.mostrarInformacion();
        System.out.println();
        f4.mostrarInformacion();
    }
}



